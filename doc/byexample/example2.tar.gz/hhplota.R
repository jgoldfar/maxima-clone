##   hhplota.R
##   combine surface of section plots
##  21 values of py

E = 0.1
y = 0.095
py = 0.096
tL = seq(0,1000,0.1)

ypy = xsection(E, y, py)

plot(ypy[[1]],ypy[[2]], pch=19, cex=0.05, xlab="y",
         ylab="py", xlim=c(-0.5,0.6), ylim=c(-0.6,0.6))
         
pyval = c(0.005,0.02, 0.03, 0.032, 0.04,0.05, 0.06, 0.07,
            0.08, 0.09,0.1, 0.2, 0.25, 0.301, 0.302, 0.303,
            0.32018, 0.3202, 0.33, 0.4)

for (py in pyval) {
   ypy = xsection(E, y, py)
   points(ypy[[1]],ypy[[2]],pch=19,cex=0.05)}
         
